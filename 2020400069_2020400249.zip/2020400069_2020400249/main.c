#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
// Defining max expression size.
#define MAX_EXPR_SIZE 100

// Size definitions for rotation functions.

#define BIT_SIZE 64


// Enumerable token types for comparing and assigning.
enum token_type
{
    TOKEN_INVALID = 0,
    TOKEN_ASSIGN = 1,
    TOKEN_LPAREN = 2,
    TOKEN_RPAREN = 3,
    TOKEN_XOR = 4,
    TOKEN_LS = 4,
    TOKEN_RS = 4,
    TOKEN_LR = 4,
    TOKEN_RR = 4,
    TOKEN_AND = 5,
    TOKEN_OR= 5,
    TOKEN_PLUS = 6,
    TOKEN_MINUS = 6,
    TOKEN_MULTIPLY = 7,
    TOKEN_NOT = 8,
    TOKEN_NUMBER,
    TOKEN_VARIABLE,
    TOKEN_COMMA,
    TOKEN_END,

};

// Token structure with type, name and value.
struct token
{
    enum token_type type;
    long long int value;
    char name[256];
};

// Global token array for save defined variables.
struct token var_tokens[100];
int var_token_count = 0;

// Function that performs left rotation.
long long int left_rotator(long long int number, long long int rotation)
{
    rotation = rotation % BIT_SIZE;
    return ( (number << rotation)) | (number >> (BIT_SIZE - rotation));

}

// Function that performs right rotation.
long long int right_rotator(long long int number, long long int rotation)
{
    rotation = rotation % BIT_SIZE;
    return (number >> rotation) | (number << (BIT_SIZE - rotation));

}


// Postfix evaluator that prints out the conclusion.
void postfix_evaluator(struct token *postfix_tokens)
{
    // Declaring a stack and 3 int variable.
    long long int val1, val2, result;
    long long int stack[MAX_EXPR_SIZE];
    int top = -1;

    // If head of the postfix_tokens is invalid, print error.
    if(postfix_tokens[0].type == TOKEN_INVALID)
    {
        printf("%s", "Error!\n");
        return;
    }

        // If postfix_tokens is empty, do nothing.
    else if(postfix_tokens[0].type == TOKEN_END)
    {
        printf("%s", "");
        return;
    }

        // If postfix_tokens' first element is equal sign, evaluate right side of it
        // and change the value of variable on the left side
        // and add it to the global var_tokens array.
    else if(postfix_tokens[1].type == TOKEN_ASSIGN)
    {
        int i = 2;
        // Iterate through right side.
        while(postfix_tokens[i].type != TOKEN_END)
        {
            // If token is number add it to the stack.
            if(postfix_tokens[i].type == TOKEN_NUMBER)
            {
                stack[++top] = postfix_tokens[i].value;
            }
                // If token is variable look to var_tokens for its value.
                // If it is not in the var_tokens its value is 0.
            else if(postfix_tokens[i].type == TOKEN_VARIABLE)
            {
                int is_var = 0;
                for(int j = 0; j < var_token_count; j++)
                {
                    if(strcmp(var_tokens[j].name, postfix_tokens[i].name) == 0)
                    {
                        is_var++;
                        stack[++top] = var_tokens[j].value;
                        break;
                    }
                }
                if(is_var == 0)
                {
                    stack[++top] = 0;
                }
            }
                // if token is not pop one element from the stack and evaluate.
            else if(strcmp(postfix_tokens[i].name, "TOKEN_NOT") == 0)
            {
                val1 = stack[top--];
                result = ~val1;
                stack[++top] = result;
            }
                // If token is an operator or function other than not pop two elements from the stack and evaluate
            else if(postfix_tokens[i].type == TOKEN_AND  || postfix_tokens[i].type == TOKEN_MINUS || postfix_tokens[i].type == TOKEN_PLUS || postfix_tokens[i].type == TOKEN_MULTIPLY || postfix_tokens[i].type == TOKEN_XOR)
            {
                if(top < 1)
                {
                    printf("%s", "Error!\n");
                    return;
                }
                else {
                    val1 = stack[top--];
                    val2 = stack[top--];
                    if (strcmp(postfix_tokens[i].name, "TOKEN_AND") == 0) {
                        result = val2 & val1;
                        stack[++top] = result;
                    } else if (strcmp(postfix_tokens[i].name, "TOKEN_OR") == 0) {
                        result = val2 | val1;
                        stack[++top] = result;
                    } else if (strcmp(postfix_tokens[i].name, "TOKEN_PLUS") == 0) {
                        result = val2 + val1;
                        stack[++top] = result;
                    } else if (strcmp(postfix_tokens[i].name, "TOKEN_MINUS") == 0) {
                        result = val2 - val1;
                        stack[++top] = result;
                    } else if (strcmp(postfix_tokens[i].name, "TOKEN_MULTIPLY") == 0) {
                        result = val2 * val1;
                        stack[++top] = result;
                    } else if (strcmp(postfix_tokens[i].name, "TOKEN_XOR") == 0) {
                        result = val2 ^ val1;
                        stack[++top] = result;
                    } else if (strcmp(postfix_tokens[i].name, "TOKEN_LS") == 0) {
                        result = val2 << val1;
                        stack[++top] = result;
                    } else if (strcmp(postfix_tokens[i].name, "TOKEN_RS") == 0) {
                        result = val2 >> val1;
                        stack[++top] = result;
                    } else if (strcmp(postfix_tokens[i].name, "TOKEN_LR") == 0) {
                        if (val1 < 0) {
                            printf("%s", "Error!\n");
                        }
                        result = left_rotator(val2, val1);
                        stack[++top] = result;
                    } else if (strcmp(postfix_tokens[i].name, "TOKEN_RR") == 0) {
                        if (val1 < 0) {
                            printf("%s", "Error!\n");
                        }
                        result = right_rotator(val2, val1);
                        stack[++top] = result;
                    }
                }
            }
            i++;
        }
        // Result is the element that is at the top of stack.
        result = stack[top];
        // Update variable's value and add it to the var_tokens if it is not in already.
        postfix_tokens[0].value = result;
        int is_var = 0;
        for(int j = 0; j < var_token_count; j++)
        {
            if(strcmp(var_tokens[j].name, postfix_tokens[0].name) == 0)
            {
                is_var++;
                var_tokens[j] = postfix_tokens[0];
                break;
            }
        }
        if(is_var == 0)
        {
            var_tokens[var_token_count] = postfix_tokens[0];
            var_token_count++;
        }

    }
        // If postfix_tokens' first element is not equal sign, evaluate whole of it
        // and print the value.
    else
    {
        int i = 0;
        // Iterate through postfix_tokens.
        while(postfix_tokens[i].type != TOKEN_END)
        {
            // If token is number add it to the stack.
            if(postfix_tokens[i].type == TOKEN_NUMBER)
            {
                stack[++top] = postfix_tokens[i].value;
            }
                // If token is variable look to var_tokens for its value.
                // If it is not in the var_tokens its value is 0.
            else if(postfix_tokens[i].type == TOKEN_VARIABLE)
            {
                int is_var = 0;
                for(int j = 0; j < var_token_count; j++)
                {
                    if(strcmp(var_tokens[j].name, postfix_tokens[i].name) == 0)
                    {
                        is_var++;
                        stack[++top] = var_tokens[j].value;
                        break;
                    }
                }
                if(is_var == 0)
                {
                    stack[++top] = 0;
                }
            }
                // if token is not pop one element from the stack and evaluate.
            else if(strcmp(postfix_tokens[i].name, "TOKEN_NOT") == 0)
            {
                val1 = stack[top--];
                result = ~val1;
                stack[++top] = result;
            }
                // If token is an operator or function other than not pop two elements from the stack and evaluate
            else if(postfix_tokens[i].type == TOKEN_AND  || postfix_tokens[i].type == TOKEN_MINUS || postfix_tokens[i].type == TOKEN_PLUS || postfix_tokens[i].type == TOKEN_MULTIPLY || postfix_tokens[i].type == TOKEN_XOR)
            {
                if(top < 1)
                {
                    printf("%s", "Error!\n");
                    return;
                }
                else
                {
                    val1 = stack[top--];
                    val2 = stack[top--];
                    if(strcmp(postfix_tokens[i].name, "TOKEN_AND") == 0)
                    {
                        result = val2 & val1;
                        stack[++top] = result;
                    }

                    else if(strcmp(postfix_tokens[i].name, "TOKEN_OR") == 0)
                    {
                        result = val2 | val1;
                        stack[++top] = result;
                    }

                    else if(strcmp(postfix_tokens[i].name, "TOKEN_PLUS") == 0)
                    {
                        result = val2 + val1;
                        stack[++top] = result;
                    }
                    else if(strcmp(postfix_tokens[i].name, "TOKEN_MINUS") == 0)
                    {
                        result = val2 - val1;
                        stack[++top] = result;
                    }
                    else if(strcmp(postfix_tokens[i].name, "TOKEN_MULTIPLY") == 0)
                    {
                        result = val2 * val1;
                        stack[++top] = result;
                    }
                    else if(strcmp(postfix_tokens[i].name, "TOKEN_XOR") == 0)
                    {
                        result = val2 ^ val1;
                        stack[++top] = result;
                    }
                    else if(strcmp(postfix_tokens[i].name, "TOKEN_LS") == 0)
                    {
                        result = val2 << val1;
                        stack[++top] = result;
                    }
                    else if(strcmp(postfix_tokens[i].name, "TOKEN_RS") == 0)
                    {
                        result = val2 >> val1;
                        stack[++top] = result;
                    }
                    else if(strcmp(postfix_tokens[i].name, "TOKEN_LR") == 0)
                    {
                        if(val1 < 0)
                        {
                            printf("%s", "Error!\n");
                        }
                        result = left_rotator(val2, val1);
                        stack[++top] = result;
                    }
                    else if(strcmp(postfix_tokens[i].name, "TOKEN_RR") == 0)
                    {
                        if(val1 < 0)
                        {
                            printf("%s", "Error!\n");
                        }
                        result = right_rotator(val2, val1);
                        stack[++top] = result;
                    }
                }
            }
            i++;
        }
        result = stack[top];
        // Result is the element that is at the top of stack.
        printf("%lli\n", result);
        // Print it.
        return;
    }

}

struct token *postfix(struct token *tokens)
{
    // Initializing the postfix_tokens array pointer, 2 stacks and needed int variables.
    struct token *postfix_tokens = malloc(MAX_EXPR_SIZE * sizeof(struct token));
    int i = 0;
    int j = 0;
    struct token stack[MAX_EXPR_SIZE];
    struct token func_stack[MAX_EXPR_SIZE];
    int top = -1;
    int func_top = -1;

    // If head of the tokens array is invalid return invalid token.
    if(tokens[0].type == TOKEN_INVALID)
    {
        postfix_tokens[0].type = TOKEN_INVALID;
        return postfix_tokens;
    }
    // Iterate through tokens.
    while (tokens[i].type != TOKEN_END)
    {
        // If the scanned token is number or variable
        // add it to the postfix array
        if(tokens[i].type == TOKEN_NUMBER || tokens[i].type == TOKEN_VARIABLE)
        {
            if(i>0 && (tokens[i-1].type == TOKEN_NUMBER || tokens[i-1].type == TOKEN_VARIABLE))
            {
                postfix_tokens[0].type = TOKEN_INVALID;
                return postfix_tokens;
            }
            postfix_tokens[j++] = tokens[i];
        }
            // If first element is assign look and zeroth element is variable add assign to the postfix array.
        else if(tokens[i].type == TOKEN_ASSIGN)
        {
            if(i != 1 || tokens[i-1].type != TOKEN_VARIABLE)
            {
                postfix_tokens[0].type = TOKEN_INVALID;
                return postfix_tokens;
            }

            else
            {
                postfix_tokens[j++] = tokens[i];
            }

        }
            // If the scanned token is open parenthesis
            // add it to the stack
        else if(tokens[i].type == TOKEN_LPAREN)
        {
            stack[++top] = tokens[i];
        }
            // If the scanned token is closing parenthesis
            // add it to the stack
        else if(tokens[i].type == TOKEN_RPAREN)
        {
            if(tokens[i-1].type == TOKEN_LPAREN)
            {
                postfix_tokens[0].type = TOKEN_INVALID;
                return postfix_tokens;
            }
            // while top of the stack is not open parenthesis
            // pop from stack and add to the postfix array
            while (top > -1 && stack[top].type != TOKEN_LPAREN)
            {
                postfix_tokens[j++] = stack[top--];
            }
            // If there is no open parenthesis in stack return Invalid token.
            if (top == -1)
            {
                postfix_tokens[0].type = TOKEN_INVALID;
                return postfix_tokens;
            }
                // decrement top by one to pop open parenthesis from it
            else
            {
                top--;
            }

        }
            // If the scanned token is an infix operator
            // Push it in the stack with respect to its precedence.
        else if(tokens[i].type == TOKEN_AND || tokens[i].type == TOKEN_MINUS || tokens[i].type == TOKEN_PLUS || tokens[i].type == TOKEN_MULTIPLY)
        {
            if(strcmp(tokens[i].name, "TOKEN_MINUS") == 0)
            {
                if(i == 0 || (tokens[i-1].type != TOKEN_VARIABLE && tokens[i-1].type != TOKEN_NUMBER && tokens[i-1].type != TOKEN_RPAREN))
                {
                    postfix_tokens[0].type = TOKEN_INVALID;
                    return postfix_tokens;
                }
            }
            while(top > -1 && stack[top].type >= tokens[i].type)
            {
                postfix_tokens[j++] = stack[top--];
            }
            stack[++top] = tokens[i];
        }
            // If the scanned token is "not" function
            // Look for open parenthesis after it for proper syntax.
            // Push it in the stack with respect to its precedence.
        else if(strcmp(tokens[i].name, "TOKEN_NOT") == 0)
        {
            if(tokens[i+1].type != TOKEN_LPAREN)
            {
                postfix_tokens[0].type = TOKEN_INVALID;
                return postfix_tokens;
            }
            while(top > -1 && stack[top].type >= tokens[i].type)
            {
                postfix_tokens[j++] = stack[top--];
            }
            stack[++top] = tokens[i];
        }
            // If the scanned token is a function other than not
            // Look for open parenthesis after it for proper syntax.
            // Push it in the func stack.
        else if(tokens[i].type == TOKEN_XOR)
        {
            if(tokens[i+1].type != TOKEN_LPAREN)
            {
                postfix_tokens[0].type = TOKEN_INVALID;
                return postfix_tokens;
            }
            func_stack[++func_top] = tokens[i];
        }
            // If the scanned token is a comma
            // Look to the func_stack.
            // If it is not empty pop from it and add to the main stack with respect to popped functions precedence.
        else if(tokens[i].type == TOKEN_COMMA)
        {
            if(func_top == -1)
            {
                postfix_tokens[0].type = TOKEN_INVALID;
                return postfix_tokens;
            }
            else
            {
                while(top > -1 && stack[top].type >= func_stack[func_top].type)
                {
                    postfix_tokens[j++] = stack[top--];
                }
                stack[++top] = func_stack[func_top--];
            }
        }
        i++;
    }
    // Add elements from stack to postfix array till stack be empty.
    while (top > -1)
    {
        if (stack[top].type == TOKEN_LPAREN)
        {
            postfix_tokens[0].type = TOKEN_INVALID;
            return postfix_tokens;
        }
        postfix_tokens[j++] = stack[top--];
    }
    // If there is element in func_stack that is a syntax error.
    if(func_top != -1)
    {
        postfix_tokens[0].type = TOKEN_INVALID;
        return postfix_tokens;
    }
    // Add end token and return.
    postfix_tokens[j].type = TOKEN_END;
    return postfix_tokens;
}

struct token *lexer(const char *input)
{
    // Initializing the tokens array pointer and needed int variables.
    struct token *tokens = malloc(MAX_EXPR_SIZE * sizeof(struct token));
    int i = 0;
    int token_count = 0;
    // Iterate through input till enter.
    while (input[i] != '\n')
    {
        // Skip whitespaces.
        if ((input[i] == ' ') || (input[i] == '\t'))
        {
            i++;
        }
            // If there is a comment line in the input, break.
        else if(input[i] == '%')
        {
            break;
        }
            // If input is digit add it to the token array.
        else if (isdigit(input[i]))
        {
            // Read number.
            long long int value = strtoll(input + i, NULL,10);
            tokens[token_count].type = TOKEN_NUMBER;
            tokens[token_count].value = value;
            token_count++;
            // Advance i to the end of number.
            while (isdigit(input[i]))
            {
                i++;
            }
        }
            // If input is alphabetical look if it is function or not.
        else if(isalpha(input[i]))
        {
            int a = 0;
            char temp[256] = "";
            while(isalpha(input[i]))
            {
                temp[a] = input[i];
                a++;
                i++;
            }
            if(strcmp(temp, "xor") == 0)
            {
                tokens[token_count].type = TOKEN_XOR;
                strcpy(tokens[token_count].name, "TOKEN_XOR");
            }
            else if(strcmp(temp, "ls") == 0)
            {
                tokens[token_count].type = TOKEN_LS;
                strcpy(tokens[token_count].name, "TOKEN_LS");
            }
            else if(strcmp(temp, "rs") == 0)
            {
                tokens[token_count].type = TOKEN_RS;
                strcpy(tokens[token_count].name, "TOKEN_RS");
            }
            else if(strcmp(temp, "lr") == 0)
            {
                tokens[token_count].type = TOKEN_LR;
                strcpy(tokens[token_count].name, "TOKEN_LR");
            }
            else if(strcmp(temp, "rr") == 0)
            {
                tokens[token_count].type = TOKEN_RR;
                strcpy(tokens[token_count].name, "TOKEN_RR");
            }
            else if(strcmp(temp, "not") == 0)
            {
                tokens[token_count].type = TOKEN_NOT;
                strcpy(tokens[token_count].name, "TOKEN_NOT");
            }
            else
            {
                tokens[token_count].type = TOKEN_VARIABLE;
                strcpy(tokens[token_count].name, temp);
                tokens[token_count].value = 0;
            }
            token_count++;
        }
            // If input is assign mark add it to the token array.
        else if (input[i] == '=')
        {
            tokens[token_count].type = TOKEN_ASSIGN;
            token_count++;
            i++;
        }
            // If input is comma add it to the token array.
        else if (input[i] == ',')
        {
            tokens[token_count].type = TOKEN_COMMA;
            token_count++;
            i++;
        }
            // If input is plus sign add it to the token array.
        else if (input[i] == '+')
        {
            tokens[token_count].type = TOKEN_PLUS;
            strcpy(tokens[token_count].name, "TOKEN_PLUS");
            token_count++;
            i++;
        }
            // If input is minus sign add it to the token array.
        else if (input[i] == '-')
        {
            tokens[token_count].type = TOKEN_MINUS;
            strcpy(tokens[token_count].name, "TOKEN_MINUS");
            token_count++;
            i++;
        }
            // If input is multiplication sign add it to the token array.
        else if (input[i] == '*')
        {
            tokens[token_count].type = TOKEN_MULTIPLY;
            strcpy(tokens[token_count].name, "TOKEN_MULTIPLY");
            token_count++;
            i++;
        }
            // If input is bitwise and sign add it to the token array.
        else if (input[i] == '&')
        {
            tokens[token_count].type = TOKEN_AND;
            strcpy(tokens[token_count].name, "TOKEN_AND");
            token_count++;
            i++;
        }
            // If input is bitwise or sign add it to the token array.
        else if (input[i] == '|')
        {
            tokens[token_count].type = TOKEN_OR;
            strcpy(tokens[token_count].name, "TOKEN_OR");
            token_count++;
            i++;
        }
            // If input is open parenthesis sign add it to the token array.
        else if(input[i] == '(')
        {
            tokens[token_count].type = TOKEN_LPAREN;
            token_count++;
            i++;
        }
            // If input is closing parenthesis sign add it to the token array.
        else if(input[i] == ')')
        {
            tokens[token_count].type = TOKEN_RPAREN;
            token_count++;
            i++;
        }
        else
        {
            // Invalid input.
            tokens[0].type = TOKEN_INVALID;
            return tokens;
        }
    }
    // Add end token before finishing.
    tokens[token_count].type = TOKEN_END;
    return tokens;
}


int main()
{
    char input[256];
    printf("> ");
    // Main loop for getting input from the user
    while (fgets(input, 256, stdin) != NULL)
    {
        // Using lexer function to tokenize input
        struct token *tokens = lexer(input);
        // Using postfix to turn token array to the postfix.
        struct token *postfix_tokens = postfix(tokens);
        // Using postfix_evaluator to evaluate and print.
        postfix_evaluator(postfix_tokens);
        printf("> ");
    }
    return 0;
}

